# Landing Page Project 

## Table of Contents 

- [Instructions](#instructions) 

- [ES6](#es6) 

- [Done](#done) 

## Instructions 

The starter project has some HTML and CSS styling to show a static form of 

the Landing Page project. You'll have to change over this task from a static 

undertaking to an intuitive one. This will require changing the HTML and CSS 

documents, yet fundamentally the JavaScript record. 

To begin, open 'js/app.js' and begin working out the application's usefulness 

For explicit, nitty gritty directions, take a gander at the undertaking guidelines in the 

Udacity Classroom. 

## Done 

This venture has been upgraded with dynamic produced Navigation list (in view of 

the areas) in an unordered list just as scolling to the part.