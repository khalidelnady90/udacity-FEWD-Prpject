/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/
/**
 * Define Global Variables
 * 
*/

const sections = Array.from(document.querySelectorAll('section'));
const navMenu = document.getElementById('navbar__list');
let numOfListItems = sections.length;

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/
  
function createListMenu() {
  for (section of sections) {
    nameOfSection = section.getAttribute('data-nav');
    LinkOfSection = section.getAttribute('id');

    listItem = document.createElement('li');

    listItem.innerHTML = `<a class='menu__link' href='#${LinkOfSection}'>${nameOfSection}</a>`;

    navMenu.appendChild(listItem);
  }
}


function sectionInViewPort(el) {
  let sectionPos = el.getBoundingClientRect();
  return (sectionPos.top >= 0);
}

function toggleActivClass() {
  for(section of sections) {
    if(sectionInViewPort(section)) {
      if(!section.classList.contains('your-active-class')) {
        section.classList.add('your-active-class');
      }
    }else {
      section.classList.remove('your-active-class');
    }
  }
}

createListMenu();

document.addEventListener('scroll', toggleActivClass);